<?php
include "common.php";

$mode = $_POST['mode'];

if($mode == "write") {
    $subject = $_POST['subject'];
    $content = addslashes($_POST['content']);
    $now = date('Y-m-d H:i:s');

    $sql = "insert into board (subject, content, insdt) values ('$subject', '$content', '$now')";
    $ret = dbexec($sql);

    if($ret) {
        alert_redir("입력 성공", "list.php");
    } else {
        alert_redir("입력 실패", "");
    }
}