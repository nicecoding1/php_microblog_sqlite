<?php
session_start();
include "common.php";

if(isset($_REQUEST['mode'])) $mode = $_REQUEST['mode'];
else $mode = "";

if($mode == "signin") {
    $id = $_POST['id'];
    $pw = $_POST['pw'];

    $sql = "select * from user where id='$id' and id<>''";
    $row = dbqueryfetch($sql);

    if($row['id'] != "" && $row['pw'] == $pw) {
        //로그인 성공
        $_SESSION['login_id'] = $row['id'];
        $_SESSION['login_name'] = $row['name'];
        alert_redir("로그인 성공", "list.php");
    } else {
        //로그인 실패
        alert_redir("로그인 실패. 아이디와 비밀번호를 정확하게 입력해주세요!", "");
    }
} elseif($mode == "signout") {
    unset($_SESSION['login_id']);
    unset($_SESSION['login_name']);
    session_destroy();
    alert_redir("", "list.php");
}