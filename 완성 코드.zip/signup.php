<?php
include "common.php";

$mode = $_POST['mode'];

if($mode == "signup") {
    $id = $_POST['id'];
    $pw = $_POST['pw'];
    $name = $_POST['name'];
    $now = date('Y-m-d H:i:s');

    $sql = "insert into user (id, pw, name, insdt) values ('$id', '$pw', '$name', '$now')";
    $ret = dbexec($sql);

    if($ret) {
        alert_redir("회원가입이 정상적으로 처리되었습니다.", "signin_form.php");
    } else {
        alert_redir("회원가입 오류 발생! 다시 시도해주세요.", "");
    }

}