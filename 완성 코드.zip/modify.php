<?php
include "common.php";

$mode = $_POST['mode'];

if($mode == "modify") {
    $no = $_POST['no'];
    $subject = $_POST['subject'];
    $content = addslashes($_POST['content']);

    $sql = "update board set subject='$subject', content='$content' where no='$no'";
    $ret = dbexec($sql);

    if($ret) {
        alert_redir("수정 성공", "view.php?no=$no");
    } else {
        alert_redir("수정 실패", "");
    }
}